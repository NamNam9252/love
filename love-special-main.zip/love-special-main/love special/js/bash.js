console.log("HELLO");

$('doucument').ready(function(){
	var typed = new Typed('#typed',{
    stringsElement: '#typed-strings',
    backSpeed:10,
    typeSpeed: 40,
	});

});
